package fr.eseo.gpi.beanartist.modele.geom;

public class Point {
	
		static final int COORDONNEES_PAR_DEFAUT = 0 ; 

	int x ;
	int y ;
	
	public int getX() {
	return this.x ;	}

	public int getY() {
	return this.y ; }


	public void setX(int x) {
	this.x = x ;	}

	public void setY(int y) {
	this.y = y ; 	}
	
	public void déplacerVers(int x, int y) {
		this.setX(x) ; 	
		this.setY(y) ; 	}

	public void déplacerDe(int deltaX, int deltaY) {
		this.setX(getX()+deltaX) ; 		
		this.setY(getY()+deltaY) ; 	}

	public String toString() {
		 return ("["+this.getClass().getSimpleName()+"] - pos : (" + this.getX() + "," + this.getY() + ")") ; 	 }

	public Point(int x, int y ){
		setX(x) ;
		setY(y) ; 	}
	public Point(){
		setX(Point.COORDONNEES_PAR_DEFAUT) ;
		setY(Point.COORDONNEES_PAR_DEFAUT) ; 	}

}
