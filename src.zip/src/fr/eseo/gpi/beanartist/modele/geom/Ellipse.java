package fr.eseo.gpi.beanartist.modele.geom ;
import fr.eseo.gpi.beanartist.modele.geom.Forme ;

public class Ellipse extends Forme {	
		
	int hauteur ;
	int largeur ;
	Point point ;
	
		/* ~.~calcul aire et périmètres~.~ */
	public double aire () {
		double aire = Math.PI*(double)hauteur*(double)largeur ;
		return aire ;	}
	public double périmètre () {
		double perimetre = Math.PI *(double)hauteur*(double)largeur/4 ;
		return perimetre ;	}
	
	/* ~.~.~.~.~.~.~ */
	/* Constructeurs */
	/* ~.~.~.~.~.~.~ */
	
	/* ~.~ position largeur longueur ~.~ */
	public Ellipse (Point position, int hauteur, int largeur) {
		super(position,hauteur,largeur) ; 	}
	/* ~.~ Coordonnées point largeur longueur ~.~ */
	public Ellipse(int x, int y, int largeur, int hauteur) {
		this(new Point(x,y), hauteur,largeur) ; 	}
	/* ~.~ largeur longueur ~.~ */
	public Ellipse (int hauteur, int largeur) {
		this(new Point(), hauteur, largeur) ; 	}
	/* ~.~ position ~.~ */
	public Ellipse(Point position) {
		this(position, Forme.HAUTEUR_PAR_DÉFAUT, Forme.LARGEUR_PAR_DÉFAUT); 	}
	/* ~.~ rien ~.~ */
	public Ellipse () {
		this(new Point(), Forme.HAUTEUR_PAR_DÉFAUT, Forme.LARGEUR_PAR_DÉFAUT) ; }	

}
