package fr.eseo.gpi.beanartist.modele.geom;

public class Cercle extends Ellipse {
	
	public void setHauteur(int rayon) {
		this.hauteur = rayon ;
		this.largeur = rayon ; 
		}

		public void setLargeur(int rayon) {
		this.largeur = rayon ; 
		this.hauteur = rayon ; 
		}
		
		public double périmètre () {
		double perimetre = Math.PI *2*getLargeur() ; 
				return perimetre ;
		}

		/* ~.~-~.~-~.~-~.~-~.~ */
		/* ~.~Constructeurs~.~ */
		/* ~.~-~.~-~.~-~.~-~.~ */		


		/* ~.~ position largeur longueur ~.~ */
		public Cercle (Point position, int rayon) {
			super(position,rayon,rayon) ; 
		}
		/* ~.~ Coordonnées point largeur longueur ~.~ */
		public Cercle(int x, int y, int rayon) {
			this(new Point(x,y),rayon) ;
		}
		/* ~.~ largeur longueur ~.~ */
		public Cercle (int rayon) {
			this(new Point(), rayon) ;
		}
		/* ~.~ position ~.~ */
		public Cercle (Point position) {
			this(position, Forme.LARGEUR_PAR_DÉFAUT) ; 
		}
		/* ~.~ rien ~.~ */
		public Cercle () {
			this(new Point(), Forme.LARGEUR_PAR_DÉFAUT) ;
		}
			

}
