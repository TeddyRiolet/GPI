package fr.eseo.gpi.beanartist.modele.geom ;
import fr.eseo.gpi.beanartist.modele.geom.Rectangle;

public class Carré extends Rectangle {
	
	public void setHauteur(int hauteur) {
		this.hauteur = hauteur ;
		this.largeur = hauteur ; 
		}

	public void setLargeur(int largeur) {
		this.largeur = largeur ; 
		this.hauteur = largeur ;
		}
		
	public String toString() {
		return super.toString() ; 
	}
	
	/* ~.~.~.~.~.~.~*/
	/* Constructeurs*/
	/* ~.~.~.~.~.~.~*/

		/* ~.~ position largeur longueur ~.~ */
		public Carré (Point position, int cote) {
		super(position,cote,cote) ;
		}
		/* ~.~ Coordonnées point largeur longueur ~.~ */
		public Carré (int x, int y, int cote) {
			this(new Point(x,y),cote) ;
		}
		
		/* ~.~ largeur longueur ~.~ */
		public Carré (int cote) {
		super(cote,cote) ; 
		}
		
		/* ~.~ position ~.~ */
		public Carré(Point position) {
		super(position) ;
		}
		
		/* ~.~ rien ~.~ */
		public Carré () {
		super() ; 
		}
	
}
