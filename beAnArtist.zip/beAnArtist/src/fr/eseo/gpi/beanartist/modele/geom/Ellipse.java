package fr.eseo.gpi.beanartist.modele.geom ;
import fr.eseo.gpi.beanartist.modele.geom.Forme ;

public class Ellipse extends Forme {	
		
	int hauteur ;
	int largeur ;
	Point point ;
	
		/* ~.~calcul aire et périmètres~.~ */
	public double aire () {
		double aire = Math.PI*this.getHauteur()*this.getLargeur()/4 ;
		return aire ;	}
	
	public double périmètre () {
		double a = this.getHauteur() / 2.0 ; 
		double b = this.getLargeur() / 2.0 ; 
		double h = ((a-b)/(a+b))*((a-b)/(a+b)) ;
		double périmètre = Math.PI * (a+b)*(1+((3*h)/(10+Math.sqrt(4-3*h)))) ;
		return périmètre ;	}
	
	public boolean contient(Point position) {
		int a = this.getLargeur() ;
		int b = this.getHauteur() ;
		int x = position.getX() ; 
		int y = position.getY() ; 
		double test = (x/a)*(x/a)+(y/b)*(y/b) ;
		return (test == 1) ; 
	}
		
		public boolean contient(int x, int y) {
			int a = this.getLargeur() ;
			int b = this.getHauteur() ;
			int yy = y ;
			int xx = x ; 
			if (x<y) {
				yy = x ; 
				xx = y ;
			}
			double test = (xx/a)*(xx/a)+(yy/b)*(yy/b) ;
			return (test == 1) ; 
		
	}
	/* ~.~.~.~.~.~.~ */
	/* Constructeurs */
	/* ~.~.~.~.~.~.~ */
	
	/* ~.~ position largeur longueur ~.~ */
	public Ellipse (Point position, int largeur, int hauteur) {
		super(position,largeur,hauteur) ; 	}
	/* ~.~ Coordonnées point largeur longueur ~.~ */
	public Ellipse(int x, int y, int largeur, int hauteur) {
		this(new Point(x,y), largeur,hauteur) ; 	}
	/* ~.~ largeur longueur ~.~ */
	public Ellipse (int largeur, int hauteur) {
		this(new Point(), largeur, hauteur) ; 	}
	/* ~.~ position ~.~ */
	public Ellipse(Point position) {
		this(position, Forme.LARGEUR_PAR_DÉFAUT, Forme.HAUTEUR_PAR_DÉFAUT); 	}
	/* ~.~ rien ~.~ */
	public Ellipse () {
		this(new Point(), Forme.LARGEUR_PAR_DÉFAUT, Forme.HAUTEUR_PAR_DÉFAUT) ; }	

}
