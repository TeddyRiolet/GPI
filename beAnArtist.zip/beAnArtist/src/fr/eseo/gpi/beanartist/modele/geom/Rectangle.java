package fr.eseo.gpi.beanartist.modele.geom ;
import fr.eseo.gpi.beanartist.modele.geom.Forme ;

public class Rectangle extends Forme {

	int hauteur ;
	int largeur ;
	Point point ;
	
	/* ~.~calcul aire et périmètres~.~ */
	
	public double aire () {
		double aire = this.getHauteur()*this.getLargeur() ;
		return aire ;	}
	public double périmètre () {
	double périmètre = 2*(this.getHauteur() + this.getLargeur()) ; 
	return périmètre ;	}
	
	public boolean contient(Point position) {
		int a = this.getLargeur() ;
		int b = this.getHauteur() ;
		int x = position.getX() ; 
		int y = position.getY() ; 
		double test = (x/a)*(x/a)+(y/b)*(y/b) ;
		return (test == 1) ; 
	}
		
	public boolean contient(int x, int y) {
		int a = this.getLargeur() ;
		int b = this.getHauteur() ;
		int yy = y ;
		int xx = x ; 
		if (x<y) {
			yy = x ; 
			xx = y ;
		}
		double test = (xx/a)*(xx/a)+(yy/b)*(yy/b) ;
		return (test == 1) ; 
		
	}

	/* ~.~.~.~.~.~.~*/
	/* Constructeurs*/
	/* ~.~.~.~.~.~.~*/

	/* ~.~ position largeur longueur ~.~ */
	public Rectangle (Point position, int largeur, int hauteur) {
		super(position,largeur,hauteur) ; 	}
	/* ~.~ Coordonnées point largeur longueur ~.~ */
	public Rectangle(int x, int y, int largeur, int hauteur) {
		this(new Point(x,y), largeur,hauteur) ; 	}
	/* ~.~ largeur longueur ~.~ */
	public Rectangle (int largeur, int hauteur) {
		this(new Point(), largeur, hauteur) ; 	}
	/* ~.~ position ~.~ */
	public Rectangle(Point position) {
		this(position, Forme.LARGEUR_PAR_DÉFAUT, Forme.HAUTEUR_PAR_DÉFAUT) ;	}
	/* ~.~ rien ~.~ */
	public Rectangle () {
		this(new Point(),Forme.LARGEUR_PAR_DÉFAUT, Forme.HAUTEUR_PAR_DÉFAUT) ; }

}
