package fr.eseo.gpi.beanartist.modele.geom;

public class Cercle extends Ellipse {
	
	public void setHauteur(int rayon) {
		super.setHauteur(rayon) ;
		super.setLargeur(rayon) ; 		}

		public void setLargeur(int rayon) {
			super.setHauteur(rayon) ;
			super.setLargeur(rayon) ; 		}
		
		public double périmètre () {
			double périmètre = Math.PI *this.getLargeur() ; 
				return périmètre ;		}

		/* ~.~-~.~-~.~-~.~-~.~ */
		/* ~.~Constructeurs~.~ */
		/* ~.~-~.~-~.~-~.~-~.~ */		


		/* ~.~ position largeur longueur ~.~ */
		public Cercle (Point position, int rayon) {
			super(position,rayon,rayon) ; 		}
		/* ~.~ Coordonnées point largeur longueur ~.~ */
		public Cercle(int x, int y, int rayon) {
			this(new Point(x,y),rayon) ;		}
		/* ~.~ largeur longueur ~.~ */
		public Cercle (int rayon) {
			this(new Point(), rayon) ;		}
		/* ~.~ position ~.~ */
		public Cercle (Point position) {
			this(position, Forme.LARGEUR_PAR_DÉFAUT) ; 		}
		/* ~.~ rien ~.~ */
		public Cercle () {
			this(new Point(), Forme.LARGEUR_PAR_DÉFAUT) ;		}
			
}
