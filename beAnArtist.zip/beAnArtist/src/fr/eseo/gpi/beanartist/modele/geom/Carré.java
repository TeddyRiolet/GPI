package fr.eseo.gpi.beanartist.modele.geom ;
import fr.eseo.gpi.beanartist.modele.geom.Rectangle;

public class Carré extends Rectangle {
	
	public void setHauteur(int hauteur) {
		super.setHauteur(hauteur) ;
		super.setLargeur(hauteur) ; 
		}

	public void setLargeur(int largeur) {
		super.setHauteur(largeur) ;
		super.setLargeur(largeur) ; 
		}
		
	public String toString() {
		return super.toString() ; 
	}
	
	/* ~.~.~.~.~.~.~*/
	/* Constructeurs*/
	/* ~.~.~.~.~.~.~*/

		/* ~.~ position largeur longueur ~.~ */
		public Carré (Point position, int cote) {
		super(position,cote,cote) ;
		}
		/* ~.~ Coordonnées point largeur longueur ~.~ */
		public Carré (int x, int y, int cote) {
			this(new Point(x,y),cote) ;
		}
		
		/* ~.~ largeur longueur ~.~ */
		public Carré (int cote) {
		this(new Point(),cote) ; 
		}
		
		/* ~.~ position ~.~ */
		public Carré(Point position) {
		this(position, Forme.LARGEUR_PAR_DÉFAUT) ;
		}
		
		/* ~.~ rien ~.~ */
		public Carré () {
		this(new Point(), Forme.LARGEUR_PAR_DÉFAUT) ; 
		}
	
}
