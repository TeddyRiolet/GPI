package fr.eseo.gpi.beanartist.modele.geom;

public class Ligne extends Forme {
	int largeur ; 
	int hauteur ; 
	Point position ; 
	@Override
	
	/* ~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~ */
	/* Méthodes abstraites héritées de Forme */
	/* ~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~ */
	public double aire() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double périmètre() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean contient(int x, int y) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean contient(Point position) {
		// TODO Auto-generated method stub
		return false;
	}
	/* ~.~.~.~.~.~.~.~ */
	/* Autres méthodes */
	/* ~.~.~.~.~.~.~.~ */
	
	/* ~.~.~.~.~.~.~ */
	/* Constructeurs */
	/* ~.~.~.~.~.~.~ */
}
