package fr.eseo.gpi.beanartist.tests.modele.geom;
import fr.eseo.gpi.beanartist.modele.geom.Ellipse;
import fr.eseo.gpi.beanartist.modele.geom.Point;

public class EllipseTest {

	public static void main(String[] args) {

		Point p2 = new Point(12,4) ;
		Ellipse e1 = new Ellipse(p2,4,8) ; 
		Ellipse e2 = new Ellipse(7,3) ; 
		Ellipse e3 = new Ellipse(p2) ; 
		Ellipse e4 = new Ellipse() ;
		
		System.out.println(""+e1.toString()) ; 
		System.out.println(""+e2.toString()) ; 
		System.out.println(""+e3.toString()) ; 
		System.out.println(""+e4.toString()) ; 
		
			/* Mouvement Ellipse 1 */

	System.out.println ("Mouvement de l'ellipse 1 vers (1;2) puis déplacement d'un vecteur (3;3)") ;
	e1.déplacerVers(1,2) ;
	System.out.println("Ellipse 1 => Position (" + e1.getX() + ";" + e1.getY() + ")") ; 
	e1.déplacerDe(3,3) ; 
	System.out.println("Ellipse 1 => Position (" + e1.getX() + ";" + e1.getY() + ")") ; 
		
	}

}
