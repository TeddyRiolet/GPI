package fr.eseo.gpi.beanartist.tests.modele.geom ;
import fr.eseo.gpi.beanartist.modele.geom.Rectangle ;
import fr.eseo.gpi.beanartist.modele.geom.Point ;

public class RectangleTest {

	public static void main(String[] args) {
		Point p2 = new Point(12,4) ;
		Rectangle r1 = new Rectangle(p2,4,8) ; 
		Rectangle r2 = new Rectangle(7,3) ; 
		Rectangle r3 = new Rectangle(p2) ; 
		Rectangle r4 = new Rectangle() ; 
		
		System.out.println("" + r1.toString()) ; 
		System.out.println("" + r2.toString()) ; 
		System.out.println("" + r3.toString()) ; 
		System.out.println("" + r4.toString()) ; 

		/* Mouvement Rectangle 1 */

		System.out.println ("Mouvement du rectangle 1 vers (1;2) puis déplacement d'un vecteur (3;3)") ;
		r1.déplacerVers(1,2) ;
		System.out.println("Rectangle 1 => Position (" + r1.getX() + ";" + r1.getY() + ")") ; 
		r1.déplacerDe(3,3) ; 
		System.out.println("Rectangle 1 => Position (" + r1.getX() + ";" + r1.getY() + ")") ; 
	}

}
