package fr.eseo.gpi.beanartist.tests.modele.geom;

import fr.eseo.gpi.beanartist.modele.geom.Carré;
import fr.eseo.gpi.beanartist.modele.geom.Point;


public class CarréTest {

	public static void main(String[] args) {
		
		Point p1 = new Point (4,8) ; 
		Carré c1 = new Carré (p1); 
		Carré c2 = new Carré(21) ; 
		System.out.println(""+c1.toString()) ; 
		System.out.println(""+c2.toString()) ;

	}

}
