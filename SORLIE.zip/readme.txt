Bonjour,
finir complexe polaire (ComplexeTest page 60)
fini classe Abstraite Forme.

Cordialement,
