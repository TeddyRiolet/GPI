package fr.eseo.gpi.premierspas ; 
class Hello {
	public static void main (String[] args) {
		System.out.println("Bonjour cher utilisateur") ;
	}
}
