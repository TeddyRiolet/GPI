package fr.eseo.gpi.tests.projet.geom ; 
import fr.eseo.gpi.projet.geom.Point ; 
class PointTest {
	public static void main (String[] args) {
	Point p1 = new Point() ; 
	Point p2 = new Point(12,4) ;

	/* J'initialise comme un sac puis j'affiche */
	System.out.println("Point 1 : Coordonnees par defaut ; Point 2 : Coordonnees choisies") ; 
	System.out.println("") ; 
	System.out.println("Coordonnees du point 1 : (" + p1.getX() + ";" + p1.getY() + ")") ; 
	System.out.println("Coordonnees du point 2 : (" + p2.getX() + ";" + p2.getY() + ")") ; 
	System.out.println("") ; 
	/* Mouvement point 1 */

	System.out.println ("Mouvement du point 1 vers (1;2) puis déplacement d'un vecteur (3;3)") ;
	p1.DeplacerVers(1,2) ; 
	System.out.println("Coordonnees du point 1 : (" + p1.getX() + ";" + p1.getY() + ")") ; 
	p1.DeplacerDe(3,3) ; 
	System.out.println("Coordonnees du point 1 : (" + p1.getX() + ";" + p1.getY() + ")") ; 
	System.out.println("") ; 

	/*Mouvement point 2 */

	System.out.println ("Mouvement du point 2 vers (4;7) puis déplacement d'un vecteur (9;4)") ;
	p2.DeplacerVers(4,7) ; 
	System.out.println("Coordonnees du point 2 : (" + p2.getX() + ";" + p2.getY() + ")") ; 
	p2.DeplacerDe(9,4) ; 
	System.out.println("Coordonnees du point 2 : (" + p2.getX() + ";" + p2.getY() + ")") ;


}
}
