package fr.eseo.gpi.tests.projet.geom ; 
import fr.eseo.gpi.projet.geom.* ;

class CarreTest{
	public static void main (String[] args) {
		Point p1 = new Point (4,8) ; 
		Rectangle r1 = new Rectangle(p1,14,7); 
		Carre c1 = new Carre(21) ; 
		System.out.println(""+r1.toString()) ; 
		System.out.println(""+c1.toString()) ;
			
	}

}
