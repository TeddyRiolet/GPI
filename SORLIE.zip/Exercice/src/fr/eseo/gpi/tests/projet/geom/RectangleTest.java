package fr.eseo.gpi.tests.projet.geom ; 
import fr.eseo.gpi.projet.geom.Rectangle ; 
import fr.eseo.gpi.projet.geom.Point ; 
class RectangleTest {
	public static void main (String[] args) {
	Point p2 = new Point(12,4) ;
	Rectangle r1 = new Rectangle(p2,4,8) ; 
	Rectangle r2 = new Rectangle(7,3) ; 
	Rectangle r3 = new Rectangle(p2) ; 
	Rectangle r4 = new Rectangle() ; 
	
	/* J'initialise puis j'affiche */
	
	System.out.println("Rectangle 1 => Longueur : " + r1.getHauteur() + " ; Largeur : " + r1.getLargeur() + " ; Position de départ : (" + 			r1.getX() + ";" + r1.getY() + "), de périmètre : " + r1.périmètre()+ " et d'aire : " + r1.aire() ) ; 

	/* ~.~ --.~.~.--.~.~.--.~.~.-- ~.~ */
		System.out.println("") ; 
	/* ~.~ --.~.~.--.~.~.--.~.~.-- ~.~ */
	System.out.println("Rectangle 2 => Longueur : " + r2.getHauteur() + " ; Largeur : " + r2.getLargeur() + " ; Position de départ : (" + 			r2.getX() + ";" + r2.getY() + "), de périmètre : " + r2.périmètre()+ " et d'aire : " + r2.aire() ) ; 
	/* ~.~ --.~.~.--.~.~.--.~.~.-- ~.~ */
		System.out.println("") ; 
	/* ~.~ --.~.~.--.~.~.--.~.~.-- ~.~ */
	System.out.println("Rectangle 3 => Longueur : " + r3.getHauteur() + " ; Largeur : " + r3.getLargeur() + " ; Position de départ : (" + 			r3.getX() + ";" + r3.getY() + "), de périmètre : " + r3.périmètre()+ " et d'aire : " + r3.aire() ) ; 
	/* ~.~ --.~.~.--.~.~.--.~.~.-- ~.~ */
		System.out.println("") ; 
	/* ~.~ --.~.~.--.~.~.--.~.~.-- ~.~ */
	System.out.println("Rectangle 4 => Longueur : " + r4.getHauteur() + " ; Largeur : " + r4.getLargeur() + " ; Position de départ : (" + 			r4.getX() + ";" + r4.getY() + "), de périmètre : " + r4.périmètre()+ " et d'aire : " + r4.aire() ) ; 
	/* ~.~ --.~.~.--.~.~.--.~.~.-- ~.~ */
		System.out.println("~.~ --.~.~.--.~.~.--.~.~.-- ~.~") ; 
	/* ~.~ --.~.~.--.~.~.--.~.~.-- ~.~ */
	/* Mouvement Rectangle 1 */

	System.out.println ("Mouvement du rectangle 1 vers (1;2) puis déplacement d'un vecteur (3;3)") ;
	r1.déplacerVers(1,2) ;
	System.out.println("Rectangle 1 => Position (" + r1.getX() + ";" + r1.getY() + ")") ; 
	
	r1.déplacerDe(3,3) ; 
	System.out.println("Rectangle 1 => Position (" + r1.getX() + ";" + r1.getY() + ")") ; 
	/* ~.~ --.~.~.--.~.~.--.~.~.-- ~.~ */
		System.out.println("~.~ --.~.~.--.~.~.--.~.~.-- ~.~") ; 
	/* ~.~ --.~.~.--.~.~.--.~.~.-- ~.~ */
	/* Mouvement Rectangle 2 */
	
	System.out.println ("Mouvement du rectangle 2 vers (2;3) puis déplacement d'un vecteur (2;4)") ;
	r2.déplacerVers(2,2) ;
	System.out.println("Rectangle 2 => Position (" + r2.getX() + ";" + r2.getY() + ")") ; 
	r2.déplacerDe(2,4) ; 
	System.out.println("Rectangle 2 => Position (" + r2.getX() + ";" + r2.getY() + ")") ; 
	/* ~.~ --.~.~.--.~.~.--.~.~.-- ~.~ */
		System.out.println("~.~ --.~.~.--.~.~.--.~.~.-- ~.~") ; 
	/* ~.~ --.~.~.--.~.~.--.~.~.-- ~.~ */
	
	/* Mouvement Rectangle 3 */
	
	System.out.println ("Mouvement du rectangle 3 vers (1;1) puis déplacement d'un vecteur (6;2)") ;
	r3.déplacerVers(1,1) ;
	System.out.println("Rectangle 3 => Position (" + r3.getX() + ";" + r3.getY() + ")") ; 
	r3.déplacerDe(6,2) ; 
	System.out.println("Rectangle 3 => Position (" + r3.getX() + ";" + r3.getY() + ")") ; 
	/* ~.~ --.~.~.--.~.~.--.~.~.-- ~.~ */
		System.out.println("~.~ --.~.~.--.~.~.--.~.~.-- ~.~") ; 
	/* ~.~ --.~.~.--.~.~.--.~.~.-- ~.~ */
	
	/* Mouvement Rectangle 4 */
			
	System.out.println ("Mouvement du rectangle 4 vers (5;5) puis déplacement d'un vecteur (-1;-2)") ;
	r4.déplacerVers(5,5) ;
	System.out.println("Rectangle 4 => Position (" + r4.getX() + ";" + r4.getY() + ")") ; 
	r4.déplacerDe(-1,-2) ; 
	System.out.println("Rectangle 4 => Position (" + r4.getX() + ";" + r4.getY() + ")") ; 
	System.out.println("Je vais maintenant changer la taille du rectangle 4 : division par 2 de la longueur et multiplication par 3 de la largeur") ; 
	r4.setHauteur(r4.getHauteur()/2) ; 
	r4.setLargeur(r4.getLargeur()*3) ; 
	System.out.println("Rectangle 4 => Longueur : " + r4.getHauteur() + " ; Largeur : " + r4.getLargeur() + " ; Position de départ : (" + r4.getX() + ";" + r4.getY() + "), de périmètre : " + r4.périmètre()+ " et d'aire : " + r4.aire() ) ; 
	/* ~.~ --.~.~.--.~.~.--.~.~.-- ~.~ */
		System.out.println("~.~ --.~.~.--.~.~.--.~.~.-- ~.~") ; 
	/* ~.~ --.~.~.--.~.~.--.~.~.-- ~.~ */
	
}
}
