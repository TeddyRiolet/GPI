package fr.eseo.gpi.tests.projet.geom;

import fr.eseo.gpi.projet.geom.*;


public class CercleTest {
	public static void main (String[] args) {
		Point p2 = new Point(12,4) ;
		Cercle c1 = new Cercle(p2,7) ; 
		Cercle c2 = new Cercle(12) ; 
		Cercle c3 = new Cercle(p2) ; 
		Cercle c4 = new Cercle() ;
		
		System.out.println(""+c1.toString()) ; 
		System.out.println(""+c2.toString()) ; 
		System.out.println(""+c3.toString()) ; 
		System.out.println(""+c4.toString()) ; 
		
			/* Mouvement Cercle 1 */

	System.out.println ("Mouvement de l'ellipse 1 vers (1;2) puis déplacement d'un vecteur (3;3)") ;
	c1.déplacerVers(1,2) ;
	System.out.println("Cercle 1 => Position (" + c1.getX() + ";" + c1.getY() + ")") ; 
	c1.déplacerDe(3,3) ; 
	System.out.println("Cercle 1 => Position (" + c1.getX() + ";" + c1.getY() + ")") ; 
	}
	
}
