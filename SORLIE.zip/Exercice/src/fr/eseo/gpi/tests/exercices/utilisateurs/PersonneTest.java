package fr.eseo.gpi.tests.exercices.utilisateurs ; 
import fr.eseo.gpi.exercices.utilisateurs.Personne ; 
class PersonneTest {
	public static void main (String[] args) {
		/*************************/
		/*Creation des instances */
		/*************************/

		/****************************/
		/*Nouvelles Initialisations */
		/****************************/

	Personne personneUn = new Personne("Jean", "Durand", "francais", 1987) ; 
	Personne personneDeux = new Personne("Al", "Capone" , "americain", 1899) ; 
	Personne personneTrois = new Personne("James","Bond","anglais",1920) ; 
	Personne personneQuatre = new Personne("Paul","Bidule") ;

		/* Anciennes Initialisations 
	personneUn.setNom("Durand") ; 
	personneUn.setPrenom("Jean") ; 
	personneUn.setAnneeDeNaissance(1987) ; 
	personneUn.setNationalite("française") ; 
	Personne.incrementeNbPersonnes() ; 
	personneUn.identite() ;
	System.out.println(""+ personneUn.userId()) ; 

	personneDeux.setNom("Capone") ; 
	personneDeux.setPrenom("Al") ; 
	personneDeux.setAnneeDeNaissance(1899) ; 
	personneDeux.setNationalite("américain") ; 
	Personne.incrementeNbPersonnes() ; 
	personneDeux.identite() ;
	System.out.println(""+ personneDeux.userId()) ; 

	personneTrois.setNom("Bond") ; 
	personneTrois.setPrenom("James") ; 
	personneTrois.setAnneeDeNaissance(1920) ; 
	personneTrois.setNationalite("américain") ; 
	Personne.incrementeNbPersonnes() ; 
	personneTrois.identite() ; 
	System.out.println(""+ personneTrois.userId()) ; */
System.out.println(""+ personneUn.userId()) ; 
System.out.println(""+ personneDeux.userId()) ; 
System.out.println(""+ personneTrois.userId()) ; 
System.out.println(""+ personneQuatre.userId()) ; 
System.out.println("Nombre de personnes : " + personneQuatre.getNbPersonnes()) ; 
	}
}
