package fr.eseo.gpi.tests.exercices.utilisateurs ;
import fr.eseo.gpi.exercices.utilisateurs.Annuaire ; 
import fr.eseo.gpi.exercices.utilisateurs.Personne ; 
class AnnuaireTest {
	public static void main (String[] args) {
		Annuaire annuaire = new Annuaire() ; 
		/* Creation des personnes */
		Personne p1 = new Personne("Paul","Pointeau","congolais",2003) ;
		Personne p2 = new Personne("Arthur","Proquot","quasi-roux",3012) ;
		Personne p3 = new Personne("Teddy","Riolet","jawadiste",1895) ;
		Personne p4 = new Personne("Clotilde","Sattler","chevelue",1995) ;
		Personne p5 = new Personne("Gipsy","Kings","Djobi-Djobatiste",1988) ;
		Personne p6 = new Personne("Lady","Bear","australien",1980) ;
		/* Ajout des personnes à l'annuaire */
		annuaire.ajouter(p1) ; 
		annuaire.ajouter(p2) ; 
		annuaire.ajouter(p3) ; 
		annuaire.ajouter(p4) ; 
		annuaire.ajouter(p5) ; 
		
		/* Retrait de personne p2 */
		
		Personne leDisparu =annuaire.supprimer(p2.getNom()) ; 
		System.out.println(""+ leDisparu.userId()) ; 
		
		/* Ajout de la personne p6 */
		
		annuaire.ajouter(p6) ; 
		
		/*Recherche de la personne présente */
		
		String nom = p1.getNom() ; 
		Personne pTrouvee = annuaire.chercher(nom) ; 
		System.out.println(""+ pTrouvee.userId()) ; 
		
		/* Recherche de la personne non-présente */
		
		String pasla = "Josephine" ;
		Personne pAbsente = annuaire.chercher(pasla) ; 
		System.out.println(""+ pAbsente.userId()) ; 
		
	
	}
}
