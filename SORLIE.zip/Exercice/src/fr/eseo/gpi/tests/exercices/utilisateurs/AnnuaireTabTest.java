package fr.eseo.gpi.tests.exercices.utilisateurs ;
import fr.eseo.gpi.exercices.utilisateurs.Annuaire ; 
import fr.eseo.gpi.exercices.utilisateurs.Personne ; 
import fr.eseo.gpi.exercices.utilisateurs.Etudiant ; 
import fr.eseo.gpi.exercices.utilisateurs.Professeur ; 
class AnnuaireTabTest {
	public static void main (String[] args) {
		Annuaire annuaire = new Annuaire() ; 
		/* Creation des personnes */
		Personne p1 = new Personne("Paul","Pointeau","congolais",2003) ;
		Etudiant e1 = new Etudiant("Arthur","Proquot","quasi-roux",3012,12345) ;
		Professeur pr1 = new Professeur("Teddy","Riolet","jawadiste",1895) ;
			pr1.ajouterCours("soirée") ;
		/* Ajout des personnes à l'annuaire */
		annuaire.ajouter(p1) ; 
		annuaire.ajouter(e1) ; 
		annuaire.ajouter(pr1); 
	System.out.println(annuaire) ; 
}
}
