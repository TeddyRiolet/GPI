package fr.eseo.gpi.tests.exercices.complexe.polaire ; 
import fr.eseo.gpi.exercices.complexe.polaire.Complexe ; 
class ComplexeTest {
	public static void main(String[] args) {

	/*~~.~~ Creation de deux complexes et Affichage ~~.~~*/
	Complexe z1 = new Complexe(false,1,0) ;
	Complexe z2 = new Complexe(false,-7,3) ; 
	Complexe z3 = new Complexe(false,-3,-4) ;
	Complexe z4 = new Complexe (false,3,-4) ; 
	z1.affichage() ; 
	z2.affichage() ; 
	z2 = new Complexe(false,7,3) ; 
	z1.affichage() ;
	z2.affichage() ;
	z3.affichage() ;
	z4.affichage() ; 
	
	//~~.~~ Addition de deux complexes + Affichage ~~.~~
	System.out.println("~~~~~~~~~~~~~~~~~~~~~~") ; 
	System.out.println("~~~~~~~~~~~~~~~~~~~~~~") ; 
	z3 = z1.plus(z2) ; 
	System.out.println("z3 = z1 + z2 = " + z3.formeCanonique()) ; 
	
	//~~.~~ Multiplication de deux complexes + Affichage ~~.~~
	System.out.println("~~~~~~~~~~~~~~~~~~~~~~") ; 
	System.out.println("~~~~~~~~~~~~~~~~~~~~~~") ; 
	z4 = z2.fois(z1) ; 
	System.out.println("z4 = z1 * z2 = " + z4.formeCanonique()) ;  
	
	//~~.~~ Modification simple de l'argument de z1 + Affichage ~~.~~
	System.out.println("~~~~~~~~~~~~~~~~~~~~~~") ; 	
	System.out.println("~~~~~~~~~~~~~~~~~~~~~~") ; 
	z1.affichage() ;
	System.out.println("~~~~~~~~~~~~~~~~~~~~~~") ; 
	z1.setArgument(3.14) ; 
	z1.affichage() ; 
	
	
	//~~.~~ Modification simple du module de z2 + Affichage ~~.~~
	System.out.println("~~~~~~~~~~~~~~~~~~~~~~") ;
	System.out.println("~~~~~~~~~~~~~~~~~~~~~~") ;  
	z2.affichage() ;
	System.out.println("~~~~~~~~~~~~~~~~~~~~~~") ; 
	z2.setModule(0.7) ; 
	z2.affichage() ; 
	
	//~~.~~ Essai en coordonnées polaires ~~.~~
	
	Complexe zPolaire = new Complexe(true,2,1.50) ; 
	zPolaire.affichage() ; 
	
	}
}
