package fr.eseo.gpi.tests.exercices.utilisateurs ; 
import fr.eseo.gpi.exercices.utilisateurs.Etudiant ; 

class EtudiantTest {
public static void main (String[] args) {

	Etudiant EtuUn = new Etudiant("Jolly","Jumper","cheval",1960,14264) ; 
	Etudiant EtuDeux = new Etudiant("Gaston","Lagaffe",1845,12345) ; 
	System.out.println(""+EtuUn.toString()) ; 
	System.out.println(""+EtuDeux.toString()) ; 


}
}
