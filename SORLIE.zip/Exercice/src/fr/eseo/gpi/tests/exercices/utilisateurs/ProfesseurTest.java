package fr.eseo.gpi.tests.exercices.utilisateurs ; 
import fr.eseo.gpi.exercices.utilisateurs.* ; 

class ProfesseurTest {
public static void main (String[] args) {

	Professeur profUn = new Professeur("Antoine","Daniel","francophone",1980) ; 
	Professeur profDeux = new Professeur("Rocky","Balboa",1975) ; 
	Professeur profTrois = new Professeur("Pomme","D'api") ; 
	
	profUn.ajouterCours("maths") ; 
	profUn.ajouterCours("philo") ; 
	profUn.ajouterCours("proba") ; 
	System.out.println("" + profUn.toString()) ;
	profUn.ajouterCours("poivrons") ; 
	System.out.println("" + profUn.toString()) ; 
	System.out.println("" + profDeux.toString()) ;
	System.out.println("" + profTrois.toString()) ;


}
}
