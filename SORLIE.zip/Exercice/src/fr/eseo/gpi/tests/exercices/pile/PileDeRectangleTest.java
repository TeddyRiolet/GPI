package fr.eseo.gpi.tests.exercices.pile ; 
import fr.eseo.gpi.exercices.pile.PileDeRectangle ; 
import fr.eseo.gpi.projet.geom.Rectangle ;
import fr.eseo.gpi.projet.geom.Point ;  

class PileDeRectangleTest {
	public static void main (String[] args) {
		PileDeRectangle pileRectangle = new PileDeRectangle() ;
		Point p1 = new Point(1,1) ; 
		Point p2 = new Point(2,2) ; 
		Point p3 = new Point(3,3) ; 
		Point p4 = new Point(4,4) ; 
		Point p5 = new Point(5,5) ; 
		Rectangle r1 = new Rectangle(p1,100,10) ; 
		Rectangle r2 = new Rectangle(p2,200,20) ; 
		Rectangle r3 = new Rectangle(p3,300,30) ; 
		Rectangle r4 = new Rectangle(p4,400,40) ; 
		Rectangle r5 = new Rectangle(p5,500,50) ; 
		
		/* Empilement des rectangles */
		
		pileRectangle.empile(r1) ;
		pileRectangle.empile(r2) ; 
		pileRectangle.empile(r3) ; 
		pileRectangle.empile(r4) ; 
		pileRectangle.empile(r5) ; 
		
		int taille = pileRectangle.getTaille() ; 
		
		/* Et on dépile */
		
		for (int i = 1 ; i <= taille ; i++) {
		Rectangle sortie = pileRectangle.depile() ; 	
		System.out.println("Rectangle enlevé => Longueur : " + sortie.getHauteur() + " ; Largeur : " + sortie.getLargeur() + " ; Position de départ : (" + 			sortie.getX() + ";" + sortie.getY() + ")") ; 
		System.out.println("") ; 
		}
	}
}
