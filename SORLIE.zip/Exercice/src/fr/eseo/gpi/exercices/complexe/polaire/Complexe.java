package fr.eseo.gpi.exercices.complexe.polaire ; 
public class Complexe {

private double module ; 
private double argument ; 
private double reelle ; 
private double imaginaire ; 
private boolean suisPolaire ; 

/*~~.~~ Retourner les valeurs = Accesseurs ~~.~~*/
public double getModule() {
double module = Math.sqrt((this.getReelle()*this.getReelle())+(this.getImaginaire()*this.getImaginaire())) ;
return module ; 
}
public double getArgument() {
double argument ; 
double pi = 3.14159265359 ; 
if (this.getReelle() == 0) {
	if (this.getImaginaire() < 0) {	argument = 3*pi/2 ; }
	else { argument = pi/2 ; }
} else { argument = Math.atan2(this.getImaginaire() , this.getReelle())  ;}

	if (argument < 0) { argument = argument + 2*pi ;}
	return argument ; 
}

public double getReelle() {
return Math.cos(this.getArgument()) * this.getModule() ;
}

public double getImaginaire() {
return Math.sin(this.getArgument()) * this.getModule() ;
}

/*~~.~~ Changer les valeurs = Mutateurs ~~.~~*/
public void setReelle(double reelle) {
this.reelle = reelle ; 
}

public void setImaginaire(double imaginaire) {
this.imaginaire = imaginaire ; 
}


/*~~.~~ Modifier module et argument ~~.~~*/


public void setModule(double mod) {
	double coef = mod / this.getModule() ; 
	setReelle(this.getReelle() * coef) ; 
	setImaginaire(this.getImaginaire() * coef) ; 
}

public void setArgument(double arg) {
	double mod = this.getModule() ; 
	double real, imaginary ; 

	real = Math.cos(arg) * mod ;
	imaginary = Math.sin(arg) * mod ; 
	
	setReelle(real) ; 
	setImaginaire(imaginary) ; 

}

/*~~.~~ Addition complexe ~~.~~*/
public Complexe plus(Complexe autreComplexe) {
Complexe sortie = new Complexe(true); 
sortie.setReelle(reelle + autreComplexe.getReelle()) ; 
sortie.setImaginaire(imaginaire + autreComplexe.getImaginaire()) ;
return sortie ; 
} 


/*~~.~~ Multiplication complexe ~~.~~*/
public Complexe fois(Complexe autreComplexe) {
Complexe sortie = new Complexe(true); 
sortie.setReelle((reelle*autreComplexe.getReelle()) - (imaginaire*autreComplexe.getImaginaire())) ; 
sortie.setImaginaire((reelle*autreComplexe.getImaginaire()) + (imaginaire*autreComplexe.getReelle())) ;
return sortie ; 
}

/*~~.~~ Forme Canonique ~~.~~*/
public String formeCanonique() {
String sortie =("" + this.getReelle() +" + " + this.getImaginaire()+ "i") ; 
return sortie ;
}

/*~~.~~ Affichage Info ~~.~~*/

public void affichage() {
System.out.println("Affichage ~~ " + getModule()) ; 
}

/*~~.~~ Constructeurs ~~.~~*/
public Complexe(boolean suisPolaire, double module, double argument) {
if (!suisPolaire) {
setModule(module) ; 
setArgument(argument) ; 
}
else {
setReelle(1) ; 
setImaginaire(1) ; 
setArgument(argument) ; 
setModule(module) ; 
}
}
public Complexe(boolean suisPolaire) {

setReelle(0) ; 
setImaginaire(0) ; 
}

}
