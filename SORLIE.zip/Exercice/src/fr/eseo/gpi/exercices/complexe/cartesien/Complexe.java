package fr.eseo.gpi.exercices.complexe.cartesien ; 
public class Complexe {

private double reelle ; 
private double imaginaire ; 
private boolean suisPolaire ; 

/*~~.~~ Retourner les valeurs = Accesseurs ~~.~~*/
public double getReelle() {
return this.reelle ; 
}
public double getImaginaire() {
return this.imaginaire ; 
}

/*~~.~~ Changer les valeurs = Mutateurs ~~.~~*/
public void setReelle(double reelle) {
this.reelle = reelle ; 
}

public void setImaginaire(double imaginaire) {
this.imaginaire = imaginaire ; 
}

/*~~.~~ Retourner module et argument ~~.~~*/

public double getModule() {
double module = Math.sqrt((this.getReelle()*this.getReelle())+(this.getImaginaire()*this.getImaginaire())) ;
return module ; 
}

public double getArgument() {
double argument ; 
double pi = 3.14159265359 ; 
if (reelle == 0) {
	if (imaginaire < 0) {	argument = 3*pi/2 ; }
	else { argument = pi/2 ; }
} else { argument = Math.atan2(this.getImaginaire() , this.getReelle())  ;}

	if (argument < 0) { argument = argument + 2*pi ;}
	return argument ; 
}

/*~~.~~ Modifier module et argument ~~.~~*/


public void setModule(double mod) {
	double coef = mod / this.getModule() ; 
	setReelle(this.getReelle() * coef) ; 
	setImaginaire(this.getImaginaire() * coef) ; 
}

public void setArgument(double arg) {
	double mod = this.getModule() ; 
	double real, imaginary ; 

	real = Math.cos(arg) * mod ;
	imaginary = Math.sin(arg) * mod ; 
	
	setReelle(real) ; 
	setImaginaire(imaginary) ; 

}

/*~~.~~ Addition complexe ~~.~~*/
public Complexe plus(Complexe autreComplexe) {
Complexe sortie = new Complexe(); 
sortie.setReelle(reelle + autreComplexe.getReelle()) ; 
sortie.setImaginaire(imaginaire + autreComplexe.getImaginaire()) ;
return sortie ; 
} 


/*~~.~~ Multiplication complexe ~~.~~*/
public Complexe fois(Complexe autreComplexe) {
Complexe sortie = new Complexe(); 
sortie.setReelle((reelle*autreComplexe.getReelle()) - (imaginaire*autreComplexe.getImaginaire())) ; 
sortie.setImaginaire((reelle*autreComplexe.getImaginaire()) + (imaginaire*autreComplexe.getReelle())) ;
return sortie ; 
}

/*~~.~~ Forme Canonique ~~.~~*/
public String formeCanonique() {
String sortie =("" + this.getReelle() +" + " + this.getImaginaire()+ "i") ; 
return sortie ;
}

/*~~.~~ Affichage Info ~~.~~*/

public void affichage() {
System.out.println("Affichage ~~ Forme algébrique " + this.formeCanonique() + " ~~ Partie réelle : " + this.getReelle() + " ~ Partie imaginaire : " + this.getImaginaire() + " ~~ Module : " + this.getModule() + " ~~ Argument : " + this.getArgument()) ; 
}

/*~~.~~ Constructeurs ~~.~~*/
public Complexe(boolean suisPolaire, double reelleOuModule, double imaginaireOuArgument) {
if (!suisPolaire) {
setReelle(reelleOuModule) ; 
setImaginaire(imaginaireOuArgument) ; 
}
else {
setReelle(1) ; 
setImaginaire(1) ; 
setArgument(imaginaireOuArgument) ; 
setModule(reelleOuModule) ; 
}
}
public Complexe() {
setReelle(0) ; 
setImaginaire(0) ; 
}

}
