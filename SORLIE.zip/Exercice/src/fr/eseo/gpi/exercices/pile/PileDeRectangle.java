package fr.eseo.gpi.exercices.pile ; 
import fr.eseo.gpi.projet.geom.Rectangle ; 
import java.util.ArrayList ;
 
public class PileDeRectangle {
private ArrayList <Rectangle> pileRectangle ;
// Constantes de classe
 /* ~.~ Aucune pour l'instant ~.~ */
 
// Variables de classe
 /* ~.~ Aucune pour l'instant ~.~ */
 
// Variables d'instance
	//Rectangle r ; 
	//int sommet ;


/*public Rectangle getRectangle(int indice) {
return this.pileRectangle.get(indice) ; 
}*/

public int getTaille() {
return pileRectangle.size() ;  
}

public boolean isVide() {
	return (pileRectangle.size()==0) ; 
}
		
public Rectangle getSommet() {
	if (isVide()) {
		throw new Error("Pile Vide") ;
		} else {
		return pileRectangle.get(pileRectangle.size()-1) ; 
}
}

public void empile(Rectangle r) { 
	pileRectangle.add(r) ;  
}

public Rectangle depile() {
	Rectangle sortie ; 
	if (isVide()) {
		throw new Error(" Pile Vide") ; 
		} else {
		sortie = pileRectangle.get(pileRectangle.size()-1) ;
		pileRectangle.remove(pileRectangle.size()-1) ; 
		return sortie ; 
	}
}


///////////////////////
	///////////////////
	// Constructeurs //
	///////////////////
///////////////////////

public PileDeRectangle() {
pileRectangle = new ArrayList <Rectangle>() ; 
}

 
}
