package fr.eseo.gpi.exercices.utilisateurs ; 
public class Personne {
	// Constantes de classe
static final String NATIONALITE_PAR_DEFAUT =  "française";

	// Variables de classe
static int nbPersonnes ; 

	// Variables d'instance
String nom ;
String prenom ;
int anneeDeNaissance ;
String nationalite ; 

////////////////////////////////////////////////////////////////////////

//////////////////////////////
	//////////////////////////
	// Get & Set d'instance //
	//////////////////////////
//////////////////////////////

	////////////////
	// Accesseurs //
	////////////////

public String getNom() {
	return this.nom ;
} 
public String getPrenom() {
	return this.prenom ;
} 
private int getAnneeDeNaissance() {
	return this.anneeDeNaissance ; 
}
private String getNationalite() {
	return this.nationalite ; 
}

	///////////////
	// Mutateurs //
	///////////////

private void setNom(String nom) {
		/*affecte l'argument "nom" à son attribut "nom" (this.nom) */
	this.nom = nom ; 
}
private void setPrenom(String prenom) {
		/*affecte l'argument "prenom" à son attribut "prenom" (this.prenom) */
	this.prenom = prenom ; 
}
private void setAnneeDeNaissance(int anneeDeNaissance) {
	this.anneeDeNaissance = anneeDeNaissance ; 
}
private void setNationalite(String nationalite) {
	this.nationalite = nationalite ;
}

/////////////////////////////
	/////////////////////////
	// Get & Set de classe //
	/////////////////////////
/////////////////////////////

	////////////////
	// Accesseurs //
	////////////////

public static int getNbPersonnes(){
	return nbPersonnes;
}

	//////////////
	// Mutateur //
	//////////////

private static void incrementeNbPersonnes() {
	nbPersonnes ++ ; 
}

/////////////////////////////
	/////////////////////////
	// Méthodes d'instance //
	/////////////////////////
/////////////////////////////

public int age (int annee) {
	// Retour l'âge de la Personne l'annee donnée le jour de son anniversaire
	return annee - getAnneeDeNaissance() ; 
}

public String toString() {
	return  this.getPrenom() + " " + this.getNom() + " - Annee de Naissance : " + this.getAnneeDeNaissance() + " Nationalité : " + this.getNationalite(); 
}
public void identite () {
	System.out.println("" + this.getPrenom() + " " + this.getNom() + " - Annee de Naissance : " + this.getAnneeDeNaissance() + " Nationalité : " + this.getNationalite()) ; 
}

public String userId() {
String morPrenom ;
String morNom ; 
String morAnnee ;
String id ;  
	if (this == null) {
	id = "Cette personne n'existe pas" ;
	} else {
	// on enleve toutes les lettres chelous + creation des variables
	morPrenom = this.getPrenom() ;
	morPrenom.replace("é","e") ;
	morPrenom.replace("è","e") ;
	morPrenom.replace("ê","e") ;
	morPrenom.replace("ë","e") ;
	morPrenom.replace("ô","o") ;
	morPrenom.replace("û","u") ;
	morPrenom.replace("ù","u") ;
	morPrenom.replace("ü","u") ;
	morPrenom.replace("ï","i") ;
	morPrenom.replace("î","i") ;
	morPrenom.replace("ç","c") ;
	morPrenom.replace(" ","") ;
	morPrenom.replace("'","") ;
	morPrenom.replace("-","") ;

	morNom = this.getNom() ;
	morNom.replace("é","e") ;
	morNom.replace("è","e") ;
	morNom.replace("ê","e") ;
	morNom.replace("ë","e") ;
	morNom.replace("ô","o") ;
	morNom.replace("û","u") ;
	morNom.replace("ù","u") ;
	morNom.replace("ü","u") ;
	morNom.replace("ï","i") ;
	morNom.replace("î","i") ;
	morNom.replace("ç","c") ;
	morNom.replace(" ","") ;
	morNom.replace("'","") ;
	morNom.replace("-","") ;
	 
	if (morPrenom.length() < 3) {
		morPrenom = "" + morPrenom.toLowerCase() ; 
	} else {
		morPrenom = "" + morPrenom.toLowerCase().substring(0,3) ; 
	}
	if (morNom.length() < 5) {
		morNom = "" + morNom.toLowerCase() ; 
	} else {
		morNom = "" + morNom.toLowerCase().substring(0,5) ;
	}
	if (this.getAnneeDeNaissance() == 0) {
	morAnnee = "XX" ; 
	} else {
	morAnnee = "" +  (this.getAnneeDeNaissance() % 100) ; 
	}


	id = "" + morNom + morPrenom + morAnnee ; 
 
	}
	return id ;
}
///////////////////////
	///////////////////
	// Constructeurs //
	///////////////////
///////////////////////

// Personnes à 4 entrées

public Personne(String prenom, String nom, String nationalite, int anneeDeNaissance) {
	this.nom = nom ; 
	this.prenom = prenom ;
	this.nationalite = nationalite ; 
	this.anneeDeNaissance = anneeDeNaissance ; 
	Personne.incrementeNbPersonnes() ; 
}

// Personnes à 2 entrées

public Personne(String prenom, String nom) {
	setNom(nom) ; 
	setPrenom(prenom) ; 
	setAnneeDeNaissance(0) ; 
	setNationalite(Personne.NATIONALITE_PAR_DEFAUT) ; 
	Personne.incrementeNbPersonnes() ; 
}


}
