package fr.eseo.gpi.exercices.utilisateurs ; 
import fr.eseo.gpi.exercices.utilisateurs.Personne ; 
import java.util.ArrayList ;

public class Professeur extends Personne {

private ArrayList <String> cours ;

public ArrayList<String> getCours() {
	return cours ; 
}

public void ajouterCours(String c) { 
	cours.add(c) ;  
}

public String toString() {
return (super.toString() + "\n" + "Cours : " + getCours()) ; 
}

// Début constructeurs 

public Professeur(String prenom, String nom, String nationalite, int anneeDeNaissance) {
super(prenom,nom,nationalite,anneeDeNaissance) ;
cours = new ArrayList<String>() ;
}
public Professeur(String prenom, String nom, int anneeDeNaissance) {
super(prenom,nom,NATIONALITE_PAR_DEFAUT,anneeDeNaissance) ;
cours = new ArrayList<String>() ;
}
public Professeur(String prenom, String nom) {
super(prenom,nom) ; 
cours = new ArrayList<String>() ;
}


// Fin constructeurs
}

//for (ArrayList item:cours)
