package fr.eseo.gpi.exercices.utilisateurs ; 
import java.util.* ; 
public class Annuaire {
private HashMap <String, Personne> annuaire ;
// key : String, Values = Personne
static final Personne ABSENT = new Personne("","","",0) ; 
public void ajouter(Personne unePersonne) {
	String name = unePersonne.getNom() ; 
	this.annuaire.put(name,unePersonne) ; 
}

public Personne chercher(String nom) {
	if (!annuaire.containsKey(nom)) {
	return Annuaire.ABSENT ; 
	} else {
	return annuaire.get(nom) ; 
	}
}

public Personne supprimer(String nom) { 
	return annuaire.remove(nom) ; 
}

public Personne[] versTableau() {
	return (annuaire.values().toArray(new Personne[0])) ; 
	// 			valeur	en tableau	initialiser tableau 
}
///////////////////////
	///////////////////
	// Constructeurs //
	///////////////////
///////////////////////

public Annuaire() {

annuaire = new HashMap <String,Personne>() ;

}

public String toString() {
	return (Arrays.toString(this.versTableau())) ; 
}
}
