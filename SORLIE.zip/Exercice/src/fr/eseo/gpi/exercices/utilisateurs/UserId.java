package fr.eseo.gpi.exercices.utilisateurs ; 

class UserId {
public static void main (String[] args) {
// args[0] = nom 
// args[1] = prenom
// args[2] = annee de naissance

String nom = args[0] ; 
String prenom = args[1] ; 
String nationalite = args[2] ; 
int anneeDeNaissance ;
if (args.length == 3) {
anneeDeNaissance = 0 ;
} else {
anneeDeNaissance = Integer.parseInt(args[3]) ; 
}

Personne p = new Personne (nom, prenom, nationalite, anneeDeNaissance) ;
//if (args.length == 3){
//Personne p = new Personne(nom, prenom, nationalite) ; //
//}
//else {
//Personne p = new Personne(nom, prenom, nationalite, anneeDeNaissance) ; 
//}
p.identite() ; 
System.out.println(" => " + p.userId()) ; 
}
}
