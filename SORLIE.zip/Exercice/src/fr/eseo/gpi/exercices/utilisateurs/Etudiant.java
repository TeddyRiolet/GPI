package fr.eseo.gpi.exercices.utilisateurs ; 
import fr.eseo.gpi.exercices.utilisateurs.Personne ; 

public class Etudiant extends Personne {
private int numEtudiant ;

// Get & Set d'instance //

public int getNumEtudiant() {
return numEtudiant ; 
}

public void setNumEtudiant(int num){
numEtudiant = num ; 
}

public String toString() {
return (super.toString() + "\n" + "Numéro étudiant : " + getNumEtudiant()) ; 
}

public Etudiant (String prenom, String nom, String nationalite, int anneeDeNaissance, int numEtudiant) {
super(prenom, nom, nationalite, anneeDeNaissance) ; 
setNumEtudiant(numEtudiant) ; 
}

public Etudiant (String prenom, String nom, int anneeDeNaissance, int numEtudiant) {
super(prenom,nom,NATIONALITE_PAR_DEFAUT,anneeDeNaissance) ;
setNumEtudiant(numEtudiant) ; 
}
}
