package fr.eseo.gpi.projet.geom ;
import fr.eseo.gpi.projet.geom.Forme ; 
public class Rectangle extends Forme {
	// Constantes de classe
	static final Point POSITION_PAR_DEFAUT = new Point() ; 

	// Variables de classe
 /* ~.~ Aucune pour l'instant ~.~ */

	// Variables d'instance
int hauteur ; /* longueur */
int largeur ; /* largeur */
Point point ; /* Position */

////////////////////////////////////////////////////////////////////////


/////////////////////////////
	/////////////////////////
	// Get & Set de classe //
	/////////////////////////
/////////////////////////////

	////////////////
	// Accesseurs //
	////////////////

/* ~.~calcul aire et périmètres~.~ */
public double aire () {
	double aire = this.hauteur*this.largeur ;
	return aire ;
}
public double périmètre () {
double perimetre = 2*(this.hauteur + this.largeur) ; 
return perimetre ;
}


/* ~.~.~.~.~.~.~.~*/
/* Constructeurs */
/* ~.~.~.~.~.~.~.~*/

/* ~.~ position largeur longueur ~.~ */
public Rectangle (Point position, int hauteur, int largeur) {
	super(position,hauteur,largeur) ; 
}
/* ~.~ Coordonnées point largeur longueur ~.~ */
public Rectangle(int x, int y, int largeur, int hauteur) {
	this(new Point(x,y), hauteur,largeur) ; 
}
/* ~.~ largeur longueur ~.~ */
public Rectangle (int hauteur, int largeur) {
	this(new Point(), hauteur, largeur) ; 
}
/* ~.~ position ~.~ */
public Rectangle(Point position) {
	this(position, Forme.HAUTEUR_PAR_DEFAUT, Forme.LARGEUR_PAR_DEFAUT) ;
}
/* ~.~ rien ~.~ */
public Rectangle () {
	this(new Point(),Forme.HAUTEUR_PAR_DEFAUT, Forme.LARGEUR_PAR_DEFAUT) ;
}

}

