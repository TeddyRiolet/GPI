package fr.eseo.gpi.projet.geom ; 
import fr.eseo.gpi.projet.geom.Rectangle ; 

public class Carre extends Rectangle {
	
	
	public void setHauteur(int hauteur) {
	this.hauteur = hauteur ;
	this.largeur = hauteur ; 
	}

	public void setLargeur(int largeur) {
	this.largeur = largeur ; 
	this.hauteur = largeur ;
	}
	
	public String toString() {
	return super.toString() ; 
}
	///////////////////////
		///////////////////
		// Constructeurs //
		///////////////////
	///////////////////////

	/* ~.~ position largeur longueur ~.~ */
	public Carre (int cote, Point position) {
	super(position,cote,cote) ; 

	}
	
	/* ~.~ largeur longueur ~.~ */
	public Carre (int cote) {
	super(cote,cote) ; 
	}
	
	/* ~.~ position ~.~ */
	public Carre(Point position) {
	super(position) ;
	}
	
	/* ~.~ rien ~.~ */
	public Carre () {
	super() ; 
	}

}
