package fr.eseo.gpi.projet.geom ; 
import fr.eseo.gpi.projet.geom.Forme ; 

public class Ellipse extends Forme{
	static final int HAUTEUR_PAR_DEFAUT = 3 ; 
	static final int LARGEUR_PAR_DEFAUT = 10 ; 
	static final Point POSITION_PAR_DEFAUT = new Point() ; 

	// Variables de classe
 /* ~.~ Aucune pour l'instant ~.~ */

	// Variables d'instance
int hauteur ; /* longueur */
int largeur ; /* largeur */
Point point ; /* Position */


	/* ~.~calcul aire et périmètres~.~ */
public double aire () {
	double aire = Math.PI*(double)hauteur*(double)largeur ;
	return aire ;
}
public double périmètre () {
double perimetre = Math.PI *Math.sqrt(1/2*(((double)hauteur) *((double)hauteur) + ((double)largeur)*((double)largeur))) ;
return perimetre ;
}


/* ~.~ position largeur longueur ~.~ */
public Ellipse (Point position, int hauteur, int largeur) {
	super(position,hauteur,largeur) ; 
}
/* ~.~ Coordonnées point largeur longueur ~.~ */
public Ellipse(int x, int y, int largeur, int hauteur) {
	this(new Point(x,y), hauteur,largeur) ; 
}
/* ~.~ largeur longueur ~.~ */
public Ellipse (int hauteur, int largeur) {
	this(new Point(), hauteur, largeur) ; 
}
/* ~.~ position ~.~ */
public Ellipse(Point position) {
	this(position, Forme.HAUTEUR_PAR_DEFAUT, Forme.LARGEUR_PAR_DEFAUT); 

}
/* ~.~ rien ~.~ */
public Ellipse () {
	this(new Point(), Forme.HAUTEUR_PAR_DEFAUT, Forme.LARGEUR_PAR_DEFAUT) ;  
}



}
