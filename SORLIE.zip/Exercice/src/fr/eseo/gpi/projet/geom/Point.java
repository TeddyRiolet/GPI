package fr.eseo.gpi.projet.geom ; 
public class Point {
	// Constantes de classe
	static final int COORDONNEES_PAR_DEFAUT = 0 ; 

	// Variables de classe
 /* ~.~ Aucune pour l'instant ~.~ */

	// Variables d'instance
int x ; /*Abscisse*/
int y ; /*Ordonnee*/

////////////////////////////////////////////////////////////////////////

/////////////////////////////
	//////////////////////////
	// Get & Set d'instance //
	//////////////////////////
/////////////////////////////

	////////////////
	// Accesseurs //
	////////////////
public int getX() {
return this.x ;
}

public int getY() {
return this.y ; 
}


	///////////////
	// Mutateurs //
	///////////////

public void setX(int x) {
this.x = x ;
}

public void setY(int y) {
this.y = y ; 
}


////////////////////////////////////////
	/////////////////////////
	// Get & Set de classe //
	/////////////////////////
////////////////////////////////////////

	////////////////
	// Accesseurs //
	////////////////

/* ~.~ Aucun pour l'instant ~.~ */

	//////////////
	// Mutateurs //
	//////////////

/* ~.~ Aucun pour l'instant ~.~ */

/////////////////////////////
	/////////////////////////
	// Méthodes d'instance //
	/////////////////////////
/////////////////////////////

public void DeplacerVers(int x, int y) {
this.setX(x) ; 
this.setY(y) ; 
}

public void DeplacerDe(int deltaX, int deltaY) {
this.setX(getX()+deltaX) ; 
this.setY(getY()+deltaY) ; 
}

///////////////////////
	///////////////////
	// Constructeurs //
	///////////////////
///////////////////////
public Point(int x, int y ){
setX(x) ;
setY(y) ; 
}
public Point(){
setX(Point.COORDONNEES_PAR_DEFAUT) ;
setY(Point.COORDONNEES_PAR_DEFAUT) ; 
}

}
