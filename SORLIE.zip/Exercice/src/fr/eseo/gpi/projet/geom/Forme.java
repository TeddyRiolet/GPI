package fr.eseo.gpi.projet.geom;
import fr.eseo.gpi.projet.geom.Point; 

public abstract class Forme {
	public static final int LARGEUR_PAR_DEFAUT = 100 ;
	public static final int HAUTEUR_PAR_DEFAUT = 150 ; 
	
	private int largeur ; 
	private int hauteur ;
	private Point position  ;
	
	/*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~*/
	/* Constructeurs de la classe abstraite*/
	/*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~*/
	
	 public Forme (Point position, int largeur, int hauteur) {
		 setPosition(position) ; 
		 setLargeur(largeur) ; 
		 setHauteur(hauteur) ; }
	 
	public Forme() {
		this(new Point(), HAUTEUR_PAR_DEFAUT,LARGEUR_PAR_DEFAUT) ; }
	
	 public  Forme(int x, int y, int largeur, int hauteur)  {
		  this(new Point(x,y), largeur, hauteur)  ;		  }
	
	 
	 public Forme(int largeur, int hauteur) {
		 this(new Point(), largeur, hauteur) ;   }
	 
	 public Forme(Point position) {
		 this(position,HAUTEUR_PAR_DEFAUT,LARGEUR_PAR_DEFAUT) ; 
	 }
	 
	 public Point getPosition() {
		 return this.position ; 
	 }
	 
	 public void setPosition(Point position) {
		 this.position = position ;
	 }
	 
	 public int getHauteur() {
		 return this.hauteur ;
	 }
	 
	 public void setHauteur(int hauteur) {
		 this.hauteur = hauteur ; 
	 }

	 public int getLargeur() {
		 return this.largeur ; 
	 }
	 
	 public void setLargeur(int largeur) {
		 this.largeur = largeur ; 
	 }
	 
	 public int getX() {
		 return this.position.x ;
	 }

	 public int getY() {
		 return this.position.y ; 
	 }
	 
	 public void setX(int x) {
		 this.position.x = x ;
	 }

	 public void setY(int y) {
		 this.position.y = y ; 
	 }
	 
	 public int getMaxX () {
		 return (this.getX() + largeur) ; 
	 }
	 
	 public int getMinX() {
		 return this.getX() ; 
	 }
	 
	 public int getMaxY () {
		 return (this.getY() + hauteur) ; 
	 }
	 public int getMinY() {
		 return this.getY() ; 
	 }
	 
	 public void déplacerVers(int x, int y) {
		 this.setX(x) ; 
		 this.setY(y) ; 
	 }

	 public void déplacerDe(int deltaX, int deltaY) {
		 this.setX(getX()+deltaX) ; 
		 this.setY(getY()+deltaY) ; 
	 }
	 
	 public abstract double aire() ;
	 
	 public abstract double périmètre() ;
	 
	 public String toString() {
		 return ("["+this.getClass().getSimpleName()+"] - pos : (" + this.getX() + "," + this.getY() + ") - dim " + this.getHauteur() + " x " + this.getLargeur() + " - périmètre : " + this.périmètre() + " - aire : " + this.aire()) ; 
	 }
}
